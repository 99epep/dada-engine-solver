"""Construction of simulation objects from validated configuration."""

from __future__ import annotations

import math

from dada_solver.configuration import SimulationConfiguration
from dada_solver.dynamics import ThermodynamicModel, ValveTopology
from dada_solver.heat_transfer import ReservoirHeatTransfer
from dada_solver.hydraulics import CompressibleOrifice
from dada_solver.integration import CycleIntegrator
from dada_solver.kinematics import HarmonicVolumeKinematics, IdealPiecewiseLinearVolumeKinematics
from dada_solver.periodic import SuccessiveCycleSolver
from dada_solver.state import ThermodynamicState, UniformCharge
from dada_solver.valves import PassiveCheckValve, ValveState


def build_model(configuration: SimulationConfiguration) -> ThermodynamicModel:
    """Build the first-level model without adding unconfigured physical data."""

    if configuration.kinematics_type == "harmonic_example":
        assert configuration.small_phase_offset_degrees is not None
        kinematics = HarmonicVolumeKinematics(
            configuration.machine_volumes.small_cylinder,
            configuration.machine_volumes.large_cylinder,
            math.radians(configuration.small_phase_offset_degrees),
        )
    else:
        assert configuration.small_lambda_target is not None
        assert configuration.large_lambda_target is not None
        assert configuration.adiabatic_sector_fraction is not None
        kinematics = IdealPiecewiseLinearVolumeKinematics(
            configuration.machine_volumes.small_cylinder,
            configuration.machine_volumes.large_cylinder,
            configuration.small_lambda_target,
            configuration.large_lambda_target,
            configuration.adiabatic_sector_fraction,
        )
    hydraulics = configuration.hydraulics
    flow_models = configuration.hydraulic_flow_models
    large_hot_model = (
        CompressibleOrifice(hydraulics.large_to_hot_cda)
        if flow_models is None else flow_models.large_to_hot
    )
    small_cold_model = (
        CompressibleOrifice(hydraulics.small_to_cold_cda)
        if flow_models is None else flow_models.small_to_cold
    )
    hot_small_model = (
        CompressibleOrifice(hydraulics.hot_to_small_valve_cda)
        if flow_models is None else flow_models.hot_to_small_valve
    )
    cold_large_model = (
        CompressibleOrifice(hydraulics.cold_to_large_valve_cda)
        if flow_models is None else flow_models.cold_to_large_valve
    )
    return ThermodynamicModel(
        gas=configuration.gas,
        machine_volumes=configuration.machine_volumes,
        kinematics=kinematics,
        angular_speed=configuration.angular_speed,
        cold_heat_transfer=ReservoirHeatTransfer(
            configuration.cold_thermal_conductance,
            configuration.cold_reservoir_temperature,
        ),
        hot_heat_transfer=ReservoirHeatTransfer(
            configuration.hot_thermal_conductance,
            configuration.hot_reservoir_temperature,
        ),
        large_hot_link=large_hot_model,
        small_cold_link=small_cold_model,
        hot_small_valve=PassiveCheckValve(
            hot_small_model,
            configuration.hot_to_small_valve.opening_pressure_difference,
            configuration.hot_to_small_valve.closing_pressure_difference,
        ),
        cold_large_valve=PassiveCheckValve(
            cold_large_model,
            configuration.cold_to_large_valve.opening_pressure_difference,
            configuration.cold_to_large_valve.closing_pressure_difference,
        ),
    )


def build_initial_state(
    configuration: SimulationConfiguration,
    model: ThermodynamicModel,
) -> ThermodynamicState:
    """Build the uniform filling state at theta=0, not a periodic state."""

    volumes = model.volumes(0.0)
    pressure = configuration.charge.resolved_pressure(
        configuration.gas, volumes.total
    )
    return UniformCharge(pressure, configuration.charge.temperature).create_state(
        configuration.gas, volumes
    )


def build_periodic_solver(
    configuration: SimulationConfiguration,
    model: ThermodynamicModel,
) -> SuccessiveCycleSolver:
    numerical = configuration.numerical
    integrator = CycleIntegrator(
        model=model,
        relative_tolerance=numerical.integration_relative_tolerance,
        absolute_tolerance=numerical.integration_absolute_tolerance,
        maximum_step_angle=math.radians(numerical.maximum_step_angle_degrees),
        maximum_events=numerical.maximum_valve_events_per_cycle,
        integration_method=numerical.integration_method,
    )
    return SuccessiveCycleSolver(
        integrator=integrator,
        maximum_cycles=numerical.maximum_cycles,
        relative_tolerance=numerical.periodic_relative_tolerance,
        mass_absolute_tolerance=numerical.periodic_mass_absolute_tolerance,
        energy_absolute_tolerance=numerical.periodic_energy_absolute_tolerance,
    )


def initial_valve_topology() -> ValveTopology:
    """Return the study's theta=0 nominal initial guess; passive checks follow."""

    return ValveTopology(ValveState.CLOSED, ValveState.CLOSED)
