# Proposed next steps after the motor update

Assessment dated 2026-09-08. These are recommendations, not implemented physics.

## Interpreting the existing diagnostics

The conservative solver already integrates variable temperatures and separate
cylinder/exchanger pressures. Failure to meet the configured isothermality or
pressure-equalization target therefore does not itself invalidate those balance
equations. Separate three kinds of result in a future reporting revision:

- numerical reliability: periodic convergence, conservation, refinement;
- model applicability: fluid properties, phase changes, correlation domains,
  omitted hydraulic/thermal dynamics;
- design behavior: temperature excursion, nominal phase order, useful power,
  efficiency, pressure and force requirements.

The existing isothermality metric is `(T_max-T_min)/T_reservoir`. It measures
excursion, not the mean gas/reservoir temperature difference or lost work.
It should remain available as a configurable design requirement rather than
being treated as a universal physical failure. No threshold was changed in
the nomenclature update.

Non-nominal valve order is likewise a behavior diagnostic. Ideal diodes prevent
reverse valve flow by construction, which does not validate actual valve lift,
inertia or leakage. Additional valve dynamics are justified if event/flow
sensitivity materially changes useful performance or hardware loads.

## Exchanger priority

The current code already provides channel geometry, thermal resistances,
pressure-drop closures, an external liquid-side screening model, and a fixed-
point cycle/geometry calculation. These should be reused.

The main unresolved step is predicting transfer over the actual pulsating cycle.
The fixed-point calculation currently combines an adjacent-port peak flow with
representative pressure/temperature extrema and sends a constant UA back to the
0D cycle. That is a screening approximation; the selected extrema need not occur
simultaneously. A more detailed geometry calculation alone does not remove it.

Recommended sequence:

1. Build an independently testable transient exchanger: initially a lumped
   gas/wall model, then a short chain of conservative gas volumes, wall thermal
   capacities, and external-side temperatures. Apply actual directional
   enthalpy transport and instantaneous flow histories. Couple thermal and
   hydraulic behavior with the same geometry and gas inventory.
2. Resolve the external boundary explicitly, including its heat capacity and
   flow, and include pump/fan consumption in the system performance boundary.
3. Assess pressure-loss correlations, entrance effects, collectors and bypass;
   use the existing inertia diagnostic to decide when momentum states are needed.
4. Verify steady, zero-flow, adiabatic and finite-wall-capacity limits, global
   conservation, and time/space refinement. Compare against independent
   measurements under representative pulsed flow. Quantify uncertainty in heat
   transfer and pressure loss before interpreting a geometry optimum.
5. Connect fluid-property validity checks to actual data. The present core's
   `Z` and `Cp` deviation hooks return zero for its ideal, constant-property
   model; they are not checks of real gas behavior.

## Speed and language choice

The current motor example was profiled using:

```console
PYTHONPATH=src python3 -m cProfile -o /tmp/dada-motor-profile.pstats \
    -m dada_solver examples/motor_controlled_example.toml
```

In this instrumented run, the periodic solver took approximately 15.0 s over
five cycles and 31,766 right-hand-side evaluations. About 9.6 s were spent in
the right-hand-side path and 3.0 s in continuous-diode event reconstruction.
These cumulative timings have profiling overhead and are not a Julia comparison.

First remove repeated state/geometry reconstruction and unnecessary allocations
in those measured paths, preserve the regression cases, and reuse periodic
solutions between nearby design points. Process-level parallel evaluation is
appropriate for independent candidates; shared LSODA instances should not be
assumed thread-safe.

Then benchmark a compiled numerical kernel on representative cases at matched
error tolerances. A Julia prototype is reasonable, especially for a future
larger exchanger state, but needs to include the right-hand side and event
handling rather than retaining frequent Python callbacks. Include compilation
time separately from repeated-solve time. No speedup factor is established yet.

SciPy's [LSODA interface](https://docs.scipy.org/doc/scipy/reference/generated/scipy.integrate.solve_ivp.html)
already wraps a Fortran integrator. SciML's
[ODE optimization guidance](https://docs.sciml.ai/DiffEqDocs/stable/tutorials/faster_ode_example/)
likewise emphasizes allocations, right-hand-side implementation and solver
selection. A language change can improve throughput; it cannot validate the
exchanger heat-transfer closure.
