"""External domestic-refrigerator comparison boundaries.

This module does not insert cabinet heat leaks into the DADA cycle. It keeps
standard test temperatures, cabinet loads and auxiliary electricity separate
so machine COP is not confused with appliance energy consumption.
"""

from __future__ import annotations

from dataclasses import dataclass
import math


@dataclass(frozen=True, slots=True)
class RefrigeratorTemperaturePoint:
    """One ambient-to-compartment temperature lift in kelvin."""

    name: str
    ambient_temperature: float
    compartment_temperature: float

    def __post_init__(self) -> None:
        if not self.name.strip():
            raise ValueError("Temperature-point name must not be empty.")
        for name, value in (
            ("Ambient temperature", self.ambient_temperature),
            ("Compartment temperature", self.compartment_temperature),
        ):
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive.")
        if self.ambient_temperature <= self.compartment_temperature:
            raise ValueError("Ambient temperature must exceed compartment temperature.")

    @property
    def temperature_lift(self) -> float:
        return self.ambient_temperature - self.compartment_temperature

    @property
    def carnot_cooling_cop(self) -> float:
        """Return the reversible bound at the declared boundary temperatures."""

        return self.compartment_temperature / self.temperature_lift


@dataclass(frozen=True, slots=True)
class SteadyCabinetLoad:
    """Simple external cabinet load, independent of refrigerating technology."""

    thermal_conductance: float
    internal_heat_load: float = 0.0

    def __post_init__(self) -> None:
        if not math.isfinite(self.thermal_conductance) or self.thermal_conductance <= 0.0:
            raise ValueError("Cabinet thermal conductance must be finite and positive.")
        if not math.isfinite(self.internal_heat_load) or self.internal_heat_load < 0.0:
            raise ValueError("Internal heat load must be finite and non-negative.")

    def cooling_power(self, point: RefrigeratorTemperaturePoint) -> float:
        return self.thermal_conductance * point.temperature_lift + self.internal_heat_load


@dataclass(frozen=True, slots=True)
class AppliancePowerAssessment:
    cabinet_cooling_power: float
    thermodynamic_input_power: float
    shaft_input_power: float
    total_appliance_input_power: float


def assess_appliance_power(
    point: RefrigeratorTemperaturePoint,
    cabinet: SteadyCabinetLoad,
    machine_cooling_cop: float,
    transmission_efficiency: float,
    auxiliary_power: float,
) -> AppliancePowerAssessment:
    """Propagate an explicit cabinet load through machine and appliance boundaries."""

    for name, value in (
        ("Machine cooling COP", machine_cooling_cop),
        ("Transmission efficiency", transmission_efficiency),
    ):
        if not math.isfinite(value) or value <= 0.0:
            raise ValueError(f"{name} must be finite and positive.")
    if transmission_efficiency > 1.0:
        raise ValueError("Transmission efficiency must not exceed one.")
    if not math.isfinite(auxiliary_power) or auxiliary_power < 0.0:
        raise ValueError("Auxiliary power must be finite and non-negative.")
    cooling = cabinet.cooling_power(point)
    thermodynamic = cooling / machine_cooling_cop
    shaft = thermodynamic / transmission_efficiency
    return AppliancePowerAssessment(
        cabinet_cooling_power=cooling,
        thermodynamic_input_power=thermodynamic,
        shaft_input_power=shaft,
        total_appliance_input_power=shaft + auxiliary_power,
    )
